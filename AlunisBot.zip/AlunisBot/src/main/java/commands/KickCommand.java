package commands;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Role;
import net.dv8tion.jda.api.entities.User;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

import java.awt.*;
import java.time.OffsetDateTime;
import java.util.concurrent.TimeUnit;


public class KickCommand extends ListenerAdapter {

    public void onSlashCommandInteraction(SlashCommandInteractionEvent e) {

        if (e.getName().equals("kick")) {
            Member m = e.getOption("user").getAsMember();
            User author = e.getUser();
            String reason = e.getOption("reason").getAsString();


            TextChannel log = e.getGuild().getTextChannelById("1088162925233049640");

            assert m != null;
            if (!m.hasPermission(Permission.ADMINISTRATOR)) {
                EmbedBuilder kicklog = new EmbedBuilder();
                kicklog.setTitle("Kick : " + m.getUser().getAsTag());
                kicklog.setDescription(reason);
                kicklog.setColor(Color.ORANGE);
                kicklog.setTimestamp(OffsetDateTime.now());
                kicklog.setFooter("Kicked by " + author.getAsTag());
                kicklog.setImage("https://cdn.discordapp.com/attachments/1082348748316868650/1087440017598718042/Adobe_Express_20230319_0126350_1.png");
                assert log != null;
                log.sendMessageEmbeds(kicklog.build()).queue();


                TextChannel channel = e.getGuild().getTextChannelById("1088148229083902042");
                Role kbm = e.getGuild().getRoleById("1088150386684215336");
                Role member = e.getGuild().getRoleById("1083033925863088239");

                EmbedBuilder eb = new EmbedBuilder();
                eb.setTitle("Kick");
                eb.setDescription("Du wurdest vom **Alunis Esports** Disord gekickt bitte benehme dich, falls du wieder joinen solltest!");
                eb.setColor(Color.RED);
                eb.addField("Reason", reason, true);
                eb.setFooter("Alunis Esports", "https://cdn.discordapp.com/attachments/1082348748316868650/1087440017598718042/Adobe_Express_20230319_0126350_1.png");

                assert member != null;
                e.getGuild().removeRoleFromMember(m, member).queue();

                assert kbm != null;
                e.getGuild().addRoleToMember(m, kbm).queue();

                assert channel != null;
                channel.sendMessageEmbeds(eb.build()).queue();

                e.reply("TEST").setEphemeral(true).queue();
                m.kick().reason(reason).queueAfter(3, TimeUnit.MINUTES);

            } else {
                e.reply("Du kannst keinen Admin kicken.").setEphemeral(true).queue();
            }
        }
    }
}