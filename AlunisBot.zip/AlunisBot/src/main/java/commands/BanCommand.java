package commands;

import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.events.interaction.command.UserContextInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

import java.util.concurrent.TimeUnit;


public class BanCommand extends ListenerAdapter {

    public void onSlashCommandInteraction(SlashCommandInteractionEvent e) {

        if(e.getName().equals("ban")) {
            Member m = e.getOption("user").getAsMember();
            String reason = e.getOption("reason").getAsString();

            if(!m.hasPermission(Permission.ADMINISTRATOR)) {
                m.ban(5 , TimeUnit.SECONDS).queue();
                e.reply("Du hast " + m.getEffectiveName() + " gebannt.").queue();
            } else {
                e.reply("Du kannst keinen Admin bannen.").setEphemeral(true).queue();
            }
        }
    }

    public void onUserContextInteraction (UserContextInteractionEvent event) {

        if(event.getName().equals("ban user")) {
            Member m = event.getTargetMember();
            String reason = "kein Grund";
            int deldays = 0;

            if(!m.hasPermission(Permission.ADMINISTRATOR)) {
                m.ban(deldays, TimeUnit.DAYS).reason(reason).queue();
                event.reply("Du hast " + m.getEffectiveName() + " gebannt.").queue();
            } else {
                event.reply("Du kannst keinen Admin bannen.").setEphemeral(true).queue();
            }



        }

    }

}
