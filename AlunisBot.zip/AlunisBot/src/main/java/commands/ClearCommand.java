package commands;

import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;


public class ClearCommand extends ListenerAdapter {

    public void onSlashCommandInteraction (SlashCommandInteractionEvent e) {
        Member member = e.getMember();
        if(member.hasPermission(Permission.MANAGE_ROLES)) {
            if(e.getName().equals("clear")) {
                TextChannel c = e.getOption("channel").getAsChannel().asTextChannel();
                int amount = e.getOption("amount").getAsInt();
                c.deleteMessages(c.getHistory().retrievePast(amount).complete()).queue();
                e.reply(amount + " Messages deleted in " + c.getAsMention() ).complete().deleteOriginal().queue();
            }
        }
    }
}
