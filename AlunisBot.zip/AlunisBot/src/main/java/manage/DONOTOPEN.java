package manage;

public class DONOTOPEN {

    public static String token = "MTA4NTI5MDI2NjE0OTI2NTQwOA.G-5CEA.aztDkWuyWIuc3PNh2LzdarYlvdHuSlI68QysSw";

}
