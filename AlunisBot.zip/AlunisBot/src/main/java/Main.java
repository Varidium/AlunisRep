import commands.BanCommand;
import commands.ClearCommand;
import commands.KickCommand;
import manage.DONOTOPEN;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.OnlineStatus;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.interactions.commands.Command;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.Commands;
import net.dv8tion.jda.api.requests.GatewayIntent;
import net.dv8tion.jda.api.utils.ChunkingFilter;
import net.dv8tion.jda.api.utils.MemberCachePolicy;
import net.dv8tion.jda.api.utils.cache.CacheFlag;

import java.util.EnumSet;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        String token = DONOTOPEN.token;

        JDABuilder builder = JDABuilder.createDefault(token);

        builder.setStatus(OnlineStatus.DO_NOT_DISTURB);
        builder.setActivity(Activity.listening("Alunis Esports Discord"));

        builder.setActivity(Activity.playing("Rocket League"));
        builder.setStatus(OnlineStatus.ONLINE);
        builder.setToken(DONOTOPEN.token);

        builder.enableIntents(GatewayIntent.GUILD_MESSAGES, GatewayIntent.GUILD_MEMBERS,GatewayIntent.GUILD_EMOJIS_AND_STICKERS,GatewayIntent.GUILD_VOICE_STATES,GatewayIntent.DIRECT_MESSAGES,GatewayIntent.GUILD_PRESENCES,GatewayIntent.MESSAGE_CONTENT);
        builder.setChunkingFilter(ChunkingFilter.ALL);
        builder.setMemberCachePolicy(MemberCachePolicy.ALL);

        EnumSet<CacheFlag> enumSet = EnumSet.of(CacheFlag.ONLINE_STATUS, CacheFlag.EMOJI, CacheFlag.VOICE_STATE, CacheFlag.CLIENT_STATUS);

        builder.enableCache(enumSet);

        builder.addEventListeners(new BanCommand());
        builder.addEventListeners(new ClearCommand());
        builder.addEventListeners(new KickCommand());


        JDA bot = builder.build();
        System.out.println("Ready!");

        Guild server = bot.awaitReady().getGuildById("1082348747851305100");

        assert server != null;
        server.updateCommands().addCommands(

                        Commands.slash("ban", "Bans a user from the server")
                                .addOption(OptionType.USER, "user", "The user to ban", true)
                                .addOption(OptionType.STRING, "reason", "The reason for the ban", false),
                        Commands.context(Command.Type.USER, "ban user"),
                        Commands.slash("clear", "Clears a channel")
                                .addOption(OptionType.CHANNEL, "channel", "The channel to clear", true)
                                .addOption(OptionType.INTEGER, "amount", "The amount of messages to clear",true),
                        Commands.slash("mute", "Mutes a user")
                                .addOption(OptionType.USER, "user", "The user to mute", true)
                                .addOption(OptionType.STRING, "reason", "The reason for the mute", true)
                                .addOption(OptionType.STRING,"duration", "The duration of the mute",true),
                        Commands.slash("kick", "Kicks a user")
                                .addOption(OptionType.USER, "user", "The user to kick", true)
                                .addOption(OptionType.STRING, "reason", "The reason for the ban", true)
                )
                .queue();


    }
}
